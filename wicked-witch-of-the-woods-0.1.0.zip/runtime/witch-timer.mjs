// Witch countdown: a real-time timer the GM controls and can show to the players.
// It never spawns anything. At zero it whispers the GM a reminder.

const MODULE_ID = "wicked-witch-of-the-woods";
const SETTING = "witchTimer";
const MINUTE = 60_000;

// running: counting down toward endsAt (server time, ms). Otherwise `remaining` holds the time left.
const DEFAULT_STATE = { running: false, endsAt: null, remaining: 130 * MINUTE, duration: 130 * MINUTE,
	shown: false, fired: false };

const { ApplicationV2 } = foundry.applications.api;
const t = key => game.i18n.localize(`WWOTW.timer.${key}`);
const now = () => game.time?.serverTime ?? Date.now();

function getState() {
	return { ...DEFAULT_STATE, ...game.settings.get(MODULE_ID, SETTING) };
}

function setState(changes) {
	if (!game.user.isGM) return;
	return game.settings.set(MODULE_ID, SETTING, { ...getState(), ...changes });
}

function remainingMs(state = getState()) {
	return Math.max(0, state.running ? state.endsAt - now() : state.remaining);
}

function formatTime(ms) {
	const total = Math.ceil(ms / 1000);
	const hours = Math.floor(total / 3600);
	const minutes = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
	const seconds = String(total % 60).padStart(2, "0");
	return `${hours}:${minutes}:${seconds}`;
}

class WitchTimer extends ApplicationV2 {
	static DEFAULT_OPTIONS = {
		id: "wwotw-witch-timer",
		classes: ["wwotw-timer"],
		window: { title: "WWOTW.timer.title", icon: "fa-solid fa-hourglass-half" },
		position: { width: 300, height: "auto" },
		actions: {
			toggle: WitchTimer.#toggle,
			adjust: WitchTimer.#adjust,
			reset: WitchTimer.#reset,
			show: WitchTimer.#show,
		},
	};

	static #toggle() {
		const state = getState();
		if (state.running) return setState({ running: false, endsAt: null, remaining: remainingMs(state) });
		const remaining = remainingMs(state) || state.duration;
		return setState({ running: true, endsAt: now() + remaining, remaining, fired: false });
	}

	static #adjust(event, target) {
		const state = getState();
		const remaining = Math.max(0, remainingMs(state) + Number(target.dataset.minutes) * MINUTE);
		return setState(state.running ? { endsAt: now() + remaining } : { remaining, fired: false });
	}

	static #reset() {
		const minutes = Number(this.element.querySelector("input[name=minutes]")?.value);
		const duration = Number.isFinite(minutes) && minutes > 0 ? minutes * MINUTE : getState().duration;
		return setState({ running: false, endsAt: null, remaining: duration, duration, fired: false });
	}

	static #show() {
		return setState({ shown: !getState().shown });
	}

	async _renderHTML() {
		const state = getState();
		const root = document.createElement("div");
		root.className = "wwotw-timer-body";
		root.innerHTML = `
			<div class="wwotw-timer-clock" data-wwotw-clock>${formatTime(remainingMs(state))}</div>
			<div class="wwotw-timer-row">
				<button type="button" data-action="toggle">
					<i class="fa-solid ${state.running ? "fa-pause" : "fa-play"}"></i>
					${t(state.running ? "pause" : "start")}
				</button>
				<button type="button" data-action="adjust" data-minutes="-5">&minus;5</button>
				<button type="button" data-action="adjust" data-minutes="5">+5</button>
			</div>
			<div class="wwotw-timer-row">
				<label>${t("minutes")}
					<input type="number" name="minutes" min="1" step="5" value="${Math.round(state.duration / MINUTE)}">
				</label>
				<button type="button" data-action="reset">${t("reset")}</button>
			</div>
			<div class="wwotw-timer-row">
				<button type="button" data-action="show" class="${state.shown ? "active" : ""}">
					<i class="fa-solid ${state.shown ? "fa-eye" : "fa-eye-slash"}"></i>
					${t(state.shown ? "shown" : "hidden")}
				</button>
			</div>`;
		return root;
	}

	_replaceHTML(result, content) {
		content.replaceChildren(result);
	}
}

let app;

function openTimer() {
	if (!game.user.isGM) return;
	app ??= new WitchTimer();
	if (app.rendered) app.close();
	else app.render({ force: true });
}

/** The countdown everyone sees while the GM has it shown. */
function refreshHud() {
	const state = getState();
	let hud = document.getElementById("wwotw-timer-hud");
	if (!state.shown) return hud?.remove();
	if (!hud) {
		hud = document.createElement("div");
		hud.id = "wwotw-timer-hud";
		hud.innerHTML = `<span class="label"></span><span class="clock" data-wwotw-clock></span>`;
		document.body.append(hud);
	}
	hud.querySelector(".label").textContent = t("hud");
	hud.classList.toggle("paused", !state.running);
	hud.classList.toggle("urgent", remainingMs(state) <= 10 * MINUTE);
}

function tick() {
	const state = getState();
	const left = remainingMs(state);
	for (const clock of document.querySelectorAll("[data-wwotw-clock]")) clock.textContent = formatTime(left);
	document.getElementById("wwotw-timer-hud")?.classList.toggle("urgent", left <= 10 * MINUTE);
	// Exactly one client announces the end: the active GM.
	if (state.running && left <= 0 && !state.fired && !announcing && game.users.activeGM?.isSelf) announce();
}

let announcing = false;   // the setting write can outlast a tick; don't announce twice

async function announce() {
	announcing = true;
	await setState({ running: false, endsAt: null, remaining: 0, fired: true });
	announcing = false;
	const players = game.users.filter(user => !user.isGM && user.active).length;
	const spiders = players ? game.i18n.format("WWOTW.timer.spiders", { n: Math.max(0, players - 2), players }) : "";
	ui.notifications.warn(t("expired"), { permanent: true });
	await ChatMessage.create({
		content: `<h3>${t("expired")}</h3><p>${t("arrives")}</p>${spiders ? `<p>${spiders}</p>` : ""}`,
		speaker: { alias: t("title") },
		whisper: ChatMessage.getWhisperRecipients("GM").map(user => user.id),
	});
}

Hooks.once("init", () => {
	game.settings.register(MODULE_ID, SETTING, {
		scope: "world", config: false, type: Object, default: DEFAULT_STATE,
		onChange: () => {
			refreshHud();
			tick();
			if (app?.rendered) app.render();
		},
	});

	game.keybindings.register(MODULE_ID, "toggleTimer", {
		name: "WWOTW.timer.keybinding",
		hint: "WWOTW.timer.keybindingHint",
		editable: [{ key: "KeyT", modifiers: ["Alt"] }],
		restricted: true,
		onDown: () => {
			openTimer();
			return true;
		},
	});
});

Hooks.once("ready", () => {
	game.modules.get(MODULE_ID).api = { openTimer };
	refreshHud();
	setInterval(tick, 1000);
});

// v13+: controls is an object keyed by control name, and tools is an object too.
Hooks.on("getSceneControlButtons", controls => {
	const tools = (controls.tokens ?? controls.token)?.tools;
	if (!game.user.isGM || !tools || Array.isArray(tools)) return;
	tools.wwotwTimer = {
		name: "wwotwTimer",
		title: "WWOTW.timer.title",
		icon: "fa-solid fa-hourglass-half",
		order: Object.keys(tools).length,
		button: true,
		visible: true,
		onChange: () => openTimer(),
	};
});
